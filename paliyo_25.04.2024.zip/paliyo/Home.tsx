import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  Image,
  TextInput,
  TouchableOpacity,
  Share,
  ActivityIndicator
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import BottomNavBar from './BottomNavBar';  // Make sure this path matches your file structure
import UserImage from './Assets/50x50.png'

export default function HomeScreen() {
  const [posts, setPosts] = useState([]);
  const [likes, setLikes] = useState({});
  const [showCommentBox, setShowCommentBox] = useState({});
  const [savedPosts, setSavedPosts] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [showSearchInput, setShowSearchInput] = useState(false);

  //const userIconUrl ="https://via.placeholder.com/50x50.png?text=User+1"

  useEffect(() => {
    fetchPosts();
  }, []);

  const getToken = async () => {
    try {
      const token = await AsyncStorage.getItem('userToken');
      return token;
    } catch (error) {
      console.error('Error fetching token', error);
      return null;
    }
  };

  const fetchPosts = async () => {
    setIsLoading(true);
    const token = await getToken();
    if (!token) {
      console.log('No token found, user might need to login');
      setIsLoading(false);
      return;
    }

    try {
      const response = await fetch('https://mynewapi-9ghe.onrender.com/posts/getAllPosts', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        }
      });
      const json = await response.json();
      if (response.ok) {
        setPosts(json.post);
      } else {
        throw new Error(json.message || 'Failed to fetch posts');
      }
    } catch (error) {
      console.error('Failed to fetch posts:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleLike = (postId) => {
    setLikes((prev) => ({
      ...prev,
      [postId]: !prev[postId],
    }));
  };

  const toggleSave = (postId) => {
    setSavedPosts((prev) => ({
      ...prev,
      [postId]: !prev[postId],
    }));
  };

  const handleCommentIconClick = (postId) => {
    setShowCommentBox((prevState) => ({
      ...prevState,
      [postId]: !prevState[postId],
    }));
  };

  const handleShare = async (post) => {
    try {
      await Share.share({
        message: `${post.postDescription}\nCheck out this post: ${post.postImages.mediaUrl}`,
      });
    } catch (error) {
      alert(error.message);
    }
  };

  const toggleSearchInput = () => {
    setShowSearchInput(!showSearchInput); // Toggle visibility of search input
  };

  if (isLoading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {showSearchInput && (
        <TextInput
          style={styles.searchInput}
          placeholder="Search..."
          autoFocus={true}
        />
      )}
      <FlatList
        data={posts}
        renderItem={({ item }) => (
          <View style={styles.postContainer}>
            <View style={styles.userHeader}>
            <Image
                source={UserImage}
                style={styles.userIcon}
              />
              <Text style={styles.username}>{item.postedBy.username}</Text>
            </View>
            <Image source={{ uri: item.postImages.mediaUrl }} style={styles.postImage} />
            <Text style={styles.postText}>{item.postDescription}</Text>
            <View style={styles.iconRow}>
              <TouchableOpacity
                style={styles.iconTouch}
                onPress={() => toggleLike(item._id)}>
                <FontAwesome
                  name={likes[item._id] ? 'heart' : 'heart-o'}
                  size={24}
                  color={likes[item._id] ? 'red' : 'black'}
                />
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.iconTouch}
                onPress={() => handleCommentIconClick(item._id)}>
                <FontAwesome name="comment-o" size={24} color="black" />
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.iconTouch}
                onPress={() => handleShare(item)}>
                <FontAwesome name="send-o" size={24} color="black" />
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.iconTouch}
                onPress={() => toggleSave(item._id)}>
                <FontAwesome
                  name={savedPosts[item._id] ? 'bookmark' : 'bookmark-o'}
                  size={24}
                  color={savedPosts[item._id] ? 'red' : 'black'}
                />
              </TouchableOpacity>
            </View>
            {showCommentBox[item._id] && (
              <TextInput
                style={styles.commentInput}
                placeholder="Write a comment..."
                autoFocus={true}
              />
            )}
          </View>
        )}
        keyExtractor={(item) => item._id.toString()}
      />
      <BottomNavBar toggleSearchInput={toggleSearchInput} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    marginTop: 60,
  },
  userHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 5,
  },
    username: {
    fontWeight: 'bold',
    fontSize: 20,
    color: '#333',          // Example of added color
    textTransform: 'capitalize',  // Ensures the first letter of each word is capitalized
    //textShadowColor: '#585858',   // Adds text shadow for a stylish effect
   // textShadowOffset: {width: 1, height: 1},
    textShadowRadius: 2
  },
  postContainer: {
    borderBottomWidth: 1,
    borderBottomColor: '#dedede',
    padding: 10,
  },
  postImage: {
    width: '100%',
    height: 300,
  },
  postText: {
    padding: 10,
    fontSize: 16,
  },
  iconRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
  },
  iconTouch: {
    padding: 10,
  },
  searchInput: {
    padding: 8,
    borderColor: '#ccc',
    borderWidth: 1,
    marginHorizontal: 10,
    marginBottom: 10,
  },
  userIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },  
  commentInput: {
    borderColor: '#ccc',
    borderWidth: 1,
    padding: 10,
    margin: 10,
  }
});
