import React, { useState, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  FlatList,
  Image,
  TextInput,
  TouchableOpacity,
  Share,
  ActivityIndicator,
} from 'react-native';
import { FontAwesome } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import BottomNavBar from './BottomNavBar';
import UserImage from './Assets/50x50.png';

export default function HomeScreen() {
  const [posts, setPosts] = useState([]);
  const [likes, setLikes] = useState({});
  const [showCommentBox, setShowCommentBox] = useState({});
  const [savedPosts, setSavedPosts] = useState({});
  const [isLoading, setIsLoading] = useState(true);
  const [showSearchInput, setShowSearchInput] = useState(false);
  const [expandedDescriptions, setExpandedDescriptions] = useState({});

  useEffect(() => {
    fetchPosts();
  }, []);

  const getToken = async () => {
    const token = await AsyncStorage.getItem('userToken');
    return token;
  };

  const getUser = async () => {
    const user = await AsyncStorage.getItem('user');
    return user;
  };

  const fetchPosts = async () => {
    setIsLoading(true);
    const token = await getToken();
    if (!token) {
      console.log('No token found, user might need to login');
      setIsLoading(false);
      return;
    }

    try {
      const response = await fetch('https://mynewapi-9ghe.onrender.com/posts/getAllPosts', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
      });
      const json = await response.json();
      if (response.ok) {
        setPosts(json.post);
        const newLikes = {};
        const newSavedPosts = {};
        json.post.forEach((post) => {
          const user = getUser();
          newLikes[post._id] = post.postLikes.some(like => like.likedBy === user._id);

          newSavedPosts[post._id] = post.savedBy.includes(user._id);
        });
        setLikes(newLikes);
        setSavedPosts(newSavedPosts);
      } else {
        throw new Error(json.message || 'Failed to fetch posts');
      }
    } catch (error) {
      console.error('Failed to fetch posts:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleLike = async (postId) => {
    const token = await getToken();
    const isLiked = likes[postId];
    const url = isLiked ? 'https://mynewapi-9ghe.onrender.com/posts/unlikePost' : 'https://mynewapi-9ghe.onrender.com/posts/likePost';

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ postId }),
      });
      const json = await response.json();
      if (response.ok) {
        setLikes((prev) => ({
          ...prev,
          [postId]: !prev[postId] // Toggle the like state
        }));
      } else {
        throw new Error(json.message || 'Failed to update like status');
      }
    } catch (error) {
      console.error('Failed to toggle like:', error);
    }
  };

  const toggleSave = async (postId) => {
    const token = await getToken();
    const isSaved = savedPosts[postId];
    const url = isSaved ? 'https://mynewapi-9ghe.onrender.com/posts/unsavePost' : 'https://mynewapi-9ghe.onrender.com/posts/savePost';

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ postId }),
      });
      const json = await response.json();
      if (response.ok) {
        setSavedPosts((prev) => ({
          ...prev,
          [postId]: !prev[postId] // Toggle the save state
        }));
      } else {
        throw new Error(json.message || 'Failed to update save status');
      }
    } catch (error) {
      console.error('Failed to toggle save:', error);
    }
  };

  const handleCommentIconClick = (postId) => {
    setShowCommentBox((prevState) => ({
      ...prevState,
      [postId]: !prevState[postId],
    }));
  };

  const handleShare = async (post) => {
    try {
      await Share.share({
        message: `${post.postDescription}\nCheck out this post: ${post.postImages.mediaUrl}`,
      });
    } catch (error) {
      alert(error.message);
    }
  };

  const toggleSearchInput = () => {
    setShowSearchInput(!showSearchInput);
  };

  const handleReadMore = (postId) => {
    setExpandedDescriptions((prev) => ({
      ...prev,
      [postId]: !prev[postId],
    }));
  };

  if (isLoading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#0000ff" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {showSearchInput && (
        <TextInput
          style={styles.searchInput}
          placeholder="Search..."
          autoFocus={true}
        />
      )}
      <FlatList
        data={posts}
        renderItem={({ item }) => (
          <View style={styles.postContainer}>
            <View style={styles.userHeader}>
              <Image
                source={UserImage}
                style={styles.userIcon}
              />
              <Text style={styles.username}>{item.postedBy.username}</Text>
            </View>
            <Image source={{ uri: item.postImages.mediaUrl }} style={styles.postImage} />
            <Text style={styles.postTitle}>{item.postTitle}</Text>
            {expandedDescriptions[item._id] ? (
              <View>
                <Text style={styles.postText}>{item.postDescription}</Text>
                <TouchableOpacity onPress={() => handleReadMore(item._id)}><Text style={styles.readMore}>Read less</Text></TouchableOpacity>
              </View>
            ) : (
              <View>
                <Text numberOfLines={2} ellipsizeMode="tail" style={styles.postText}>{item.postDescription}</Text>
                <TouchableOpacity onPress={() => handleReadMore(item._id)}><Text style={styles.readMore}>Read more</Text></TouchableOpacity>
              </View>
            )}
            <View style={styles.iconRow}>
              <TouchableOpacity
                style={styles.iconTouch}
                onPress={() => toggleLike(item._id)}>
                <FontAwesome
                  name={likes[item._id] ? 'heart' : 'heart-o'}
                  size={24}
                  color={likes[item._id] ? 'red' : 'black'}
                />
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.iconTouch}
                onPress={() => handleCommentIconClick(item._id)}>
                <FontAwesome name="comment-o" size={24} color="black" />
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.iconTouch}
                onPress={() => handleShare(item)}>
                <FontAwesome name="share-square-o" size={24} color="black" />
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.iconTouch}
                onPress={() => toggleSave(item._id)}>
                <FontAwesome
                  name={savedPosts[item._id] ? 'bookmark' : 'bookmark-o'}
                  size={24}
                  color={savedPosts[item._id] ? 'black' : 'grey'}
                />
              </TouchableOpacity>
            </View>
            {showCommentBox[item._id] && (
              <TextInput
                style={styles.commentBox}
                placeholder="Write a comment..."
              />
            )}
          </View>
        )}
        keyExtractor={(item) => item._id.toString()}
      />
      <BottomNavBar onSearchPress={toggleSearchInput} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 40,
  },
  searchInput: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
  },
  postContainer: {
    marginVertical: 8,
    paddingHorizontal: 12,
  },
  userHeader: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  userIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  username: {
    marginLeft: 8,
    fontSize: 16,
  },
  postImage: {
    width: '100%',
    height: 300,
    marginTop: 10,
  },
  postText: {
    marginVertical: 10,
  },
  postTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 10,
    marginBottom: 5,
  },
  iconRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
  },
  iconTouch: {
    padding: 10,
  },
  commentBox: {
    height: 40,
    borderWidth: 1,
    marginTop: 10,
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  readMore: {
    color: 'blue',
    marginBottom: 10,
  },
});
