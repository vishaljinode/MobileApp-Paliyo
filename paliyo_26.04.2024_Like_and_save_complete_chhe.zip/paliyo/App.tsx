import React from 'react';




import AppNavigator from './AppNavigator.js';

export default function App() {
  return <AppNavigator />;
}
